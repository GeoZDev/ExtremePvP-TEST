<?php
/**
 * Created by PhpStorm.
 * User: khoan
 * Date: 4/24/2016
 * Time: 9:38 PM
 */

namespace ExtremePvP;

use pocketmine\entity\Effect;
use pocketmine\event\player\PlayerEvent;
use pocketmine\item\DiamondSword;
use pocketmine\item\Item;
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as Color;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\entity\Arrow;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\level\Explosion;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\enchantment\EnchantmentList;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentEntry;

class ExtremePvP extends PluginBase implements Listener
{

    public $launch;

    public function onLoad()
    {
        $this->getLogger()->info(Color::RED . "Pronto al load...");
    }

    public function onEnable()
    {
        $this->getLogger()->notice(Color::RED . "Checking config.yml...");
        @mkdir($this->getDataFolder() . "config.yml" . Config::YAML);
        $this->saveDefaultConfig();
        $this->saveResource("config.yml");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        if($this->getConfig()->get("Extreme_mode") == false){
            $this->getLogger()->info(Color::RED . "Modalità Extreme messa in OFF!");
        }elseif ($this->getConfig()->get("Extreme_mode") == true){
            $this->getLogger()->info(Color::GOLD . "Modalità Extreme messa ON! ora il tuo server è più estremo! :D");
        }else{
            $this->getLogger()->error(Color::RED . "ERRORE rilevato: È necessario modificare il Extreme_mode variabile on/off! Disabilitando il plugin...");
            $this->getPluginLoader()->disablePlugin($this);
        }
        $this->getLogger()->info(Color::GREEN . "ExtremePvP loaddato! tradotto da GeoZDev! :D");
    }

    public function onBlockBreak(BlockBreakEvent $breakEvent)
    {
        if (strtolower($this->getConfig()->get("Protect_blocks")) == true) {
            $breakEvent->setCancelled(true);
        } elseif (strtolower($this->getConfig()->get("Protect_blocks")) == false) {
            $breakEvent->setCancelled(false);
        } else {
            $this->getLogger()->alert(Color::RED . "ERRORE: Impossibile rilevare Protect_blocks in config. yml! Ci sono 2 scelte: on/off!");
            $this->getPluginLoader()->disablePlugin($this);
        }
    }

    public function onShoot(EntityShootBowEvent $event)
    {
        $shooter = $event->getEntity();
        if ($shooter instanceof Player) {
            $id = $shooter->getId();
            $this->launch[$id] = (bool)true;
        }
    }

    public function onEvents(Item $item, ProjectileHitEvent $event, PlayerEvent $playerEvent)
    {
        $entity = $event->getEntity();
        $level = $entity->getLevel();
        if (strtolower($this->getConfig()->get("Extreme_mode")) == true) {
            if ($entity instanceof Arrow) {
                $shooter = $entity->shootingEntity;
                $pos = $entity->getPosition();
                if ($shooter instanceof Player) {
                    $id = $shooter->getId();
                    $shoot = $this->launch[$id];
                    if ($pos instanceof Position and isset($shoot)) {
                        $level->removeEntity($entity);
                        $explosion = new Explosion($pos, 4);
                        $explosion->explode();
                        unset($this->launch[$id]);
                        if ($entity instanceof Player) {
                            $entity->setOnFire(30);
                            return;
                        }
                    }
                }
            }
            $player = $playerEvent->getPlayer();
            if ($item->getId() == Item::DIAMOND_SWORD) {
                if ($player->getInventory()->getHeldItemSlot() == Item::DIAMOND_SWORD) {
                    $item->setDamage(9);
                    $player->setHealth(40);
                    $item->addEnchantment(Enchantment::getEnchantment(9));
                    $item->addEnchantment(Enchantment::getEnchantment(10));
                    $item->addEnchantment(Enchantment::getEnchantment(11));
                    $item->addEnchantment(Enchantment::getEnchantment(12));
                    $item->addEnchantment(Enchantment::getEnchantment(13));
                    $item->getEnchantment(9)->setLevel(5);
                    $item->getEnchantment(10)->setLevel(5);
                    $item->getEnchantment(11)->setLevel(5);
                    $item->getEnchantment(12)->setLevel(10);
                    $item->getEnchantment(13)->setLevel(7);
                }
            }
            if ($player->eatFoodInHand()) {
                $player->addExperience(30);
                $player->addEffect(Effect::getEffect(3));
                $player->getEffect(3)->setAmplifier(6);
                $player->addEffect(Effect::getEffect(5));
                $player->getEffect(5)->setAmplifier(8);
                $player->addEffect(Effect::getEffect(10));
                $player->getEffect(10)->setAmplifier(5);
                $player->getEffect(3)->setDuration(80);
                $player->getEffect(5)->setDuration(80);
                $player->getEffect(10)->setDuration(30);
                if ($player->eatFoodInHand() == Item::GOLDEN_APPLE) {
                    $player->addExpLevel(6);
                    $player->addEffect(Effect::getEffect(14));
                    $player->addEffect(Effect::getEffect(12));
                    $player->addEffect(Effect::getEffect(23));
                    $player->addEffect(Effect::getEffect(11));
                    $player->addEffect(Effect::getEffect(13));
                    $player->getEffect(14)->setAmplifier(5);
                    $player->getEffect(12)->setAmplifier(5);
                    $player->getEffect(23)->setAmplifier(5);
                    $player->getEffect(11)->setAmplifier(5);
                    $player->getEffect(13)->setAmplifier(5);
                    $player->getEffect(14)->setDuration(100);
                    $player->getEffect(12)->setDuration(100);
                    $player->getEffect(23)->setDuration(100);
                    $player->getEffect(11)->setDuration(100);
                    $player->getEffect(13)->setDuration(100);
                }
                return;
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args)
    {
        if (strtolower($command->getName()) == "extreme") {
            if ($sender->hasPermission("extreme.command.op")) {
                if (isset($args[0])) {
                    if (strtolower($args[0]) == "reload") {
                        $this->saveConfig();
                        $this->saveResource("config.yml");
                        $this->reloadConfig();
                        $this->saveConfig();
                        $this->saveResource("config.yml");
                        $sender->sendMessage(Color::GREEN . "ExtremePvP Reloaddato!");
                    }else{
                        $sender->sendMessage(Color::RED . "Uso: /extreme reload");
                    }
                }else{
                    $sender->sendMessage(Color::RED . "Uso: /extreme reload");
                }
            }
        }
    }

    public function onDisable()
    {
        $this->saveConfig();
        $this->saveResource("config.yml");
        $this->getLogger()->info(Color::GREEN . "Il plugin è stato disabilitato! Tradotto da GeoZDev.\nCiao! :D");
    }
}